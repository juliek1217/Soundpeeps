package com.example.soundpeeps.Matches;

public class MatchesObject {
    private String userId;

    public MatchesObject(String userId) {
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userID) {
        this.userId = userID;
    }
}